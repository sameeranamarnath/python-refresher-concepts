import mymodule

print("code.py:", __name__)

# -- can't do relative imports from the __main__ file:

# from . import mymodule
