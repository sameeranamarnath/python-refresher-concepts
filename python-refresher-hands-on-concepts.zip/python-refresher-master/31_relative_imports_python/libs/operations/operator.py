print("operator.py", __name__)

# -- can do parent imports in file with parent package --

from ..mylib import *
