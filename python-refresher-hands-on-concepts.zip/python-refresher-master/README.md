# Python Refresher
This repository contains hands on exercises, ordered by module.
Have fun
Amar.S